//! Turns one observed route into the transaction the executor can trade.
//!
//! Pools are classified by the mints they actually hold rather than by the
//! feed's `role` string: a role name can change, a pool's mint pair cannot.
use crate::config::{DirectConfig, Settlement, TransactionConfig, TriangleConfig};
use crate::observed_feed::{ObservedPool, ObservedRoute};
use crate::v10::{SOL, USDC};
use anyhow::{bail, Result};
use solana_sdk::pubkey::Pubkey;
use std::str::FromStr;

/// Header options the feed does not carry; they come from the bot's own config.
#[derive(Debug, Clone, Copy)]
pub struct Header {
    /// Profit, in settlement base units, below which the trade fails on chain.
    pub minimum_profit: u64,
    pub flashloan: bool,
    /// Succeed without trading instead of failing when there is no profit.
    pub no_failure: bool,
    /// Fixed input; 0 lets the program size the trade.
    pub trade_size: u64,
}

impl Default for Header {
    fn default() -> Self {
        Self {
            minimum_profit: 0,
            flashloan: false,
            // A revert costs a fee, so the default is to fail rather than to
            // land a no-op.
            no_failure: false,
            trade_size: 0,
        }
    }
}

pub fn settlement_of(mint: &str) -> Result<Settlement> {
    match Pubkey::from_str(mint) {
        Ok(key) if key == SOL => Ok(Settlement::Sol),
        Ok(key) if key == USDC => Ok(Settlement::Usdc),
        _ => bail!("unsupported settlement mint {mint}"),
    }
}

/// Where a pool sits in the route.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum Leg {
    /// Target against the settlement mint.
    Direct,
    /// Target against the stock mint.
    Intermediate,
    /// Stock against the settlement mint.
    Bridge,
}

fn leg_of(pool: &ObservedPool, target: &str, stock: Option<&str>, settlement: &str) -> Option<Leg> {
    match (pool.token_mint_a.as_deref(), pool.token_mint_b.as_deref()) {
        (Some(a), Some(b)) => {
            let holds = |x: &str, y: &str| (a == x && b == y) || (a == y && b == x);
            if holds(target, settlement) {
                Some(Leg::Direct)
            } else if stock.is_some_and(|s| holds(target, s)) {
                Some(Leg::Intermediate)
            } else if stock.is_some_and(|s| holds(s, settlement)) {
                Some(Leg::Bridge)
            } else {
                None
            }
        }
        // Without mints there is only the feed's own label to go on.
        _ => match pool.role.as_str() {
            "direct" => Some(Leg::Direct),
            "intermediate" => Some(Leg::Intermediate),
            "bridge" => Some(Leg::Bridge),
            _ => None,
        },
    }
}

fn parse_pools(pools: &[&ObservedPool]) -> Result<Vec<Pubkey>> {
    pools
        .iter()
        .map(|pool| {
            Pubkey::from_str(&pool.address)
                .map_err(|e| anyhow::anyhow!("invalid pool address {}: {e}", pool.address))
        })
        .collect()
}

/// The transaction for `route`, or why the route cannot be traded.
///
/// The two refusals mirror what the production client reports: a direct route
/// needs two pools to arbitrage between, and a stock route needs all three legs.
pub fn transaction_config(route: &ObservedRoute, header: Header) -> Result<TransactionConfig> {
    let settlement = settlement_of(&route.settlement_mint)?;
    let stock = route.stock_mint.as_deref();
    let mut direct = Vec::new();
    let mut intermediate = Vec::new();
    let mut bridges = Vec::new();
    for pool in &route.pools {
        match leg_of(pool, &route.target_mint, stock, &route.settlement_mint) {
            Some(Leg::Direct) => direct.push(pool),
            Some(Leg::Intermediate) => intermediate.push(pool),
            Some(Leg::Bridge) => bridges.push(pool),
            None => {}
        }
    }

    let (direct_groups, triangle_groups) = match stock {
        None => {
            if direct.len() < 2 {
                bail!(
                    "direct route {}: fewer than two usable pools",
                    route.target_mint
                );
            }
            (
                vec![DirectConfig {
                    pools: parse_pools(&direct)?,
                }],
                Vec::new(),
            )
        }
        Some(_) => {
            if intermediate.is_empty() || bridges.is_empty() || direct.is_empty() {
                bail!(
                    "observed stock route {} has no complete basket",
                    route.target_mint
                );
            }
            // The pools arrive best-first from the registry, so the leading
            // intermediate is the one that has actually produced profit.
            (
                Vec::new(),
                vec![TriangleConfig {
                    intermediate: parse_pools(&intermediate[..1])?[0],
                    bridges: parse_pools(&bridges)?,
                    direct: parse_pools(&direct)?,
                }],
            )
        }
    };

    Ok(TransactionConfig {
        settlement,
        flashloan: header.flashloan,
        minimum_profit: header.minimum_profit,
        trade_size: header.trade_size,
        no_failure: header.no_failure,
        constant_conversion: false,
        additional_fee: None,
        direct: direct_groups,
        triangle: triangle_groups,
    })
}

#[cfg(test)]
mod tests {
    use super::*;

    const SOL_MINT: &str = "So11111111111111111111111111111111111111112";
    const TARGET: &str = "4k3Dyjzvzp8eMZWUXbBCjEvwSkkk59S5iCNLY3QrkX6R";
    const STOCK: &str = "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v";
    const P1: &str = "CPMMoo8L3F4NbTegBCKVNunggL7H1ZpdTHKxQB5qKP1C";
    const P2: &str = "pAMMBay6oceH9fJKBRHGP5D4bD4sWpmSwMn52FMfXEA";
    const P3: &str = "CAMMCzo5YL8w4VFF8KVHrK22GGUsp5VTaW7grrKgrWqK";

    fn pool(address: &str, a: &str, b: &str) -> ObservedPool {
        ObservedPool {
            address: address.into(),
            dex: "pumpswap".into(),
            lookup_tables: vec![],
            max_net_profit: 0,
            profitable_tx_count: 0,
            role: String::new(),
            token_mint_a: Some(a.into()),
            token_mint_b: Some(b.into()),
            total_net_profit: 0,
        }
    }

    fn route(stock: Option<&str>, pools: Vec<ObservedPool>) -> ObservedRoute {
        ObservedRoute {
            copy_rate: None,
            fees: Default::default(),
            lookup_tables: vec![],
            max_net_profit: 1,
            pools,
            profitable_tx_count: 1,
            settlement_mint: SOL_MINT.into(),
            stock_mint: stock.map(str::to_owned),
            target_mint: TARGET.into(),
            total_net_profit: 1,
        }
    }

    #[test]
    fn direct_route_needs_two_pools() {
        let one = route(None, vec![pool(P1, TARGET, SOL_MINT)]);
        let err = transaction_config(&one, Header::default())
            .unwrap_err()
            .to_string();
        assert!(err.contains("fewer than two usable pools"), "{err}");

        let two = route(
            None,
            vec![pool(P1, TARGET, SOL_MINT), pool(P2, SOL_MINT, TARGET)],
        );
        let config = transaction_config(&two, Header::default()).unwrap();
        assert_eq!(config.direct.len(), 1);
        assert_eq!(config.direct[0].pools.len(), 2);
        assert!(config.triangle.is_empty());
    }

    #[test]
    fn stock_route_needs_every_leg() {
        let incomplete = route(
            Some(STOCK),
            vec![pool(P1, TARGET, STOCK), pool(P2, TARGET, SOL_MINT)],
        );
        let err = transaction_config(&incomplete, Header::default())
            .unwrap_err()
            .to_string();
        assert!(err.contains("no complete basket"), "{err}");

        let complete = route(
            Some(STOCK),
            vec![
                pool(P1, TARGET, STOCK),
                pool(P2, TARGET, SOL_MINT),
                pool(P3, STOCK, SOL_MINT),
            ],
        );
        let config = transaction_config(&complete, Header::default()).unwrap();
        assert_eq!(config.triangle.len(), 1);
        assert_eq!(config.triangle[0].intermediate.to_string(), P1);
        assert_eq!(config.triangle[0].bridges.len(), 1);
        assert_eq!(config.triangle[0].direct.len(), 1);
        assert!(config.direct.is_empty());
    }

    #[test]
    fn unrelated_pools_are_ignored() {
        let noise = pool(P3, "11111111111111111111111111111111", SOL_MINT);
        let r = route(
            None,
            vec![pool(P1, TARGET, SOL_MINT), pool(P2, TARGET, SOL_MINT), noise],
        );
        let config = transaction_config(&r, Header::default()).unwrap();
        assert_eq!(config.direct[0].pools.len(), 2);
    }

    #[test]
    fn falls_back_to_the_role_label_without_mints() {
        let mut a = pool(P1, TARGET, SOL_MINT);
        a.token_mint_a = None;
        a.token_mint_b = None;
        a.role = "direct".into();
        let mut b = pool(P2, TARGET, SOL_MINT);
        b.token_mint_a = None;
        b.token_mint_b = None;
        b.role = "direct".into();
        let config = transaction_config(&route(None, vec![a, b]), Header::default()).unwrap();
        assert_eq!(config.direct[0].pools.len(), 2);
    }

    #[test]
    fn header_options_reach_the_transaction() {
        let header = Header {
            minimum_profit: 50_000,
            flashloan: true,
            no_failure: true,
            trade_size: 7,
        };
        let r = route(
            None,
            vec![pool(P1, TARGET, SOL_MINT), pool(P2, TARGET, SOL_MINT)],
        );
        let config = transaction_config(&r, header).unwrap();
        assert_eq!(config.minimum_profit, 50_000);
        assert!(config.flashloan);
        assert!(config.no_failure);
        assert_eq!(config.trade_size, 7);
        assert_eq!(config.settlement, Settlement::Sol);
    }

    #[test]
    fn unknown_settlement_is_refused() {
        let mut r = route(
            None,
            vec![pool(P1, TARGET, SOL_MINT), pool(P2, TARGET, SOL_MINT)],
        );
        r.settlement_mint = TARGET.into();
        let err = transaction_config(&r, Header::default())
            .unwrap_err()
            .to_string();
        assert!(err.contains("unsupported settlement mint"), "{err}");
    }
}
