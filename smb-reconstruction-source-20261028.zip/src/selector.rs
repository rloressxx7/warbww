//! Which observed routes are worth trading.
//!
//! The filter set is the one the production client reports when it connects:
//! `min_profit`, `minimum_tx_count`, `within_secs` and `limit`, all scoped to a
//! single settlement mint.
use crate::observed_feed::{ObservedRoute, Snapshot};

/// Defaults are the values the production client logs when the config leaves
/// them unset.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct SelectionParams {
    /// Lowest `max_net_profit`, in settlement-mint base units, worth trading.
    pub min_profit: u64,
    /// How many profitable observations a route needs before it is traded.
    pub minimum_tx_count: u64,
    /// How old a snapshot may be, in seconds, before it is ignored.
    pub within_secs: u64,
    /// Most routes kept from one snapshot.
    pub limit: usize,
}

impl Default for SelectionParams {
    fn default() -> Self {
        Self {
            min_profit: 0,
            minimum_tx_count: 2,
            within_secs: 300,
            limit: 10,
        }
    }
}

/// Why a route was left out, so a skip can be logged with its reason.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Rejected {
    SettlementMismatch,
    NoPools,
    BelowMinProfit,
    TooFewTransactions,
    OverLimit,
}

/// A route kept by [`select`], with the shape the registry keys on.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Kind {
    /// Target traded straight against the settlement mint.
    Direct,
    /// Target traded through a stock mint.
    Stock,
}

pub fn kind_of(route: &ObservedRoute) -> Kind {
    match route.stock_mint {
        Some(_) => Kind::Stock,
        None => Kind::Direct,
    }
}

/// True when the snapshot is young enough to act on.
pub fn snapshot_is_fresh(snapshot: &Snapshot, now_unix: u64, within_secs: u64) -> bool {
    // A snapshot stamped in the future is treated as fresh: clock skew is not
    // a reason to discard live data.
    now_unix.saturating_sub(snapshot.generated_at_unix) <= within_secs
}

/// The routes worth trading, best first, and every rejection with its reason.
pub fn select<'a>(
    snapshot: &'a Snapshot,
    settlement_mint: &str,
    params: &SelectionParams,
) -> (Vec<&'a ObservedRoute>, Vec<(&'a ObservedRoute, Rejected)>) {
    let mut kept = Vec::new();
    let mut rejected = Vec::new();
    for route in &snapshot.routes {
        if route.settlement_mint != settlement_mint {
            rejected.push((route, Rejected::SettlementMismatch));
        } else if route.pools.is_empty() {
            rejected.push((route, Rejected::NoPools));
        } else if route.max_net_profit < params.min_profit {
            rejected.push((route, Rejected::BelowMinProfit));
        } else if route.profitable_tx_count < params.minimum_tx_count {
            rejected.push((route, Rejected::TooFewTransactions));
        } else {
            kept.push(route);
        }
    }
    // Richest first, so `limit` keeps the best rather than the first seen.
    kept.sort_by(|a, b| {
        b.max_net_profit
            .cmp(&a.max_net_profit)
            .then_with(|| b.total_net_profit.cmp(&a.total_net_profit))
            .then_with(|| a.target_mint.cmp(&b.target_mint))
    });
    for route in kept.drain(params.limit.min(kept.len())..) {
        rejected.push((route, Rejected::OverLimit));
    }
    (kept, rejected)
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::observed_feed::{ObservedPool, Snapshot};

    const SOL: &str = "So11111111111111111111111111111111111111112";
    const USDC: &str = "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v";

    fn pool() -> ObservedPool {
        ObservedPool {
            address: "pool".into(),
            dex: "pumpswap".into(),
            lookup_tables: vec![],
            max_net_profit: 0,
            profitable_tx_count: 0,
            role: "direct".into(),
            token_mint_a: None,
            token_mint_b: None,
            total_net_profit: 0,
        }
    }

    fn route(target: &str, profit: u64, txs: u64, settlement: &str) -> ObservedRoute {
        ObservedRoute {
            copy_rate: None,
            fees: Default::default(),
            lookup_tables: vec![],
            max_net_profit: profit,
            pools: vec![pool()],
            profitable_tx_count: txs,
            settlement_mint: settlement.into(),
            stock_mint: None,
            target_mint: target.into(),
            total_net_profit: profit,
        }
    }

    fn snapshot(routes: Vec<ObservedRoute>) -> Snapshot {
        Snapshot {
            bundles: vec![],
            companions: vec![],
            generated_at_unix: 1_000,
            retention_secs: 300,
            routes,
        }
    }

    #[test]
    fn keeps_only_matching_settlement() {
        let snap = snapshot(vec![route("a", 10, 5, SOL), route("b", 10, 5, USDC)]);
        let (kept, rejected) = select(&snap, SOL, &SelectionParams::default());
        assert_eq!(kept.len(), 1);
        assert_eq!(kept[0].target_mint, "a");
        assert_eq!(rejected[0].1, Rejected::SettlementMismatch);
    }

    #[test]
    fn drops_routes_below_min_profit_and_tx_count() {
        let params = SelectionParams {
            min_profit: 50_000,
            minimum_tx_count: 2,
            ..Default::default()
        };
        let snap = snapshot(vec![
            route("poor", 49_999, 9, SOL),
            route("rare", 90_000, 1, SOL),
            route("good", 60_000, 4, SOL),
        ]);
        let (kept, rejected) = select(&snap, SOL, &params);
        assert_eq!(kept.len(), 1);
        assert_eq!(kept[0].target_mint, "good");
        assert!(rejected.iter().any(|(_, r)| *r == Rejected::BelowMinProfit));
        assert!(rejected
            .iter()
            .any(|(_, r)| *r == Rejected::TooFewTransactions));
    }

    #[test]
    fn empty_pool_list_is_rejected() {
        let mut r = route("a", 10, 5, SOL);
        r.pools.clear();
        let snap = snapshot(vec![r]);
        let (kept, rejected) = select(&snap, SOL, &SelectionParams::default());
        assert!(kept.is_empty());
        assert_eq!(rejected[0].1, Rejected::NoPools);
    }

    #[test]
    fn limit_keeps_the_richest() {
        let params = SelectionParams {
            limit: 2,
            minimum_tx_count: 0,
            ..Default::default()
        };
        let snap = snapshot(vec![
            route("small", 10, 5, SOL),
            route("big", 900, 5, SOL),
            route("mid", 100, 5, SOL),
        ]);
        let (kept, rejected) = select(&snap, SOL, &params);
        let targets: Vec<&str> = kept.iter().map(|r| r.target_mint.as_str()).collect();
        assert_eq!(targets, vec!["big", "mid"]);
        assert_eq!(rejected.last().unwrap().1, Rejected::OverLimit);
    }

    #[test]
    fn stale_snapshot_is_not_fresh() {
        let snap = snapshot(vec![]);
        assert!(snapshot_is_fresh(&snap, 1_200, 300));
        assert!(!snapshot_is_fresh(&snap, 1_301, 300));
        // Clock skew must not discard live data.
        assert!(snapshot_is_fresh(&snap, 900, 300));
    }

    #[test]
    fn stock_routes_are_distinguished() {
        let mut r = route("a", 10, 5, SOL);
        assert_eq!(kind_of(&r), Kind::Direct);
        r.stock_mint = Some("stock".into());
        assert_eq!(kind_of(&r), Kind::Stock);
    }
}
