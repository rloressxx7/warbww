//! Feed-driven mode: snapshot in, transaction out.
//!
//! The chain is `feed_client` → `registry` → `route_builder` → `route` →
//! `transaction` → `simulation_gate` → `senders`. Planning is separated from
//! execution so the whole selection path can be replayed offline, with no RPC,
//! no wallet and nothing sent.
use crate::config::{Config, FeedAuth, FeedConfig};
use crate::feed_client::{self, Auth, FeedClient};
use crate::loader::AccountLoader;
use crate::observed_feed::Snapshot;
use crate::registry::RouteRegistry;
use crate::route::Route;
use crate::route_builder;
use crate::senders::SendPipeline;
use crate::transaction::build_transaction;
use anyhow::{Context, Result};
use solana_client::rpc_client::RpcClient;
use solana_sdk::signature::Keypair;
use solana_sdk::signer::Signer;
use std::path::Path;
use std::time::Duration;
use tokio::sync::mpsc;
use tracing::{info, warn};

/// One route the snapshot says is worth trading, already in executor form.
pub struct Planned {
    pub target_mint: String,
    pub stock_mint: Option<String>,
    pub config: crate::config::TransactionConfig,
}

/// Applies a snapshot and turns every surviving route into a transaction
/// config. Pure: no RPC, no wallet, no sending.
pub fn plan(
    registry: &mut RouteRegistry,
    snapshot: &Snapshot,
    feed: &FeedConfig,
) -> Vec<Planned> {
    let params = feed.selection();
    let delta = registry.apply_snapshot(snapshot, &feed.settlement_mint, &params);
    if !delta.is_empty() {
        info!(
            "Observed-arb snapshot delta => added: {}, updated: {}, removed: {}, reranked: {}",
            delta.added.len(),
            delta.updated.len(),
            delta.removed.len(),
            delta.reranked.len()
        );
    }
    // The feed stamps its own retention; fall back to the subscription window.
    let retention = match snapshot.retention_secs {
        0 => params.within_secs,
        secs => secs,
    };
    for key in registry.expire_stale(snapshot.generated_at_unix, retention) {
        info!("Route expired from the registry: {}", key.target_mint);
    }

    let header = feed.header();
    let mut planned = Vec::new();
    for registered in registry.routes() {
        match route_builder::transaction_config(&registered.route, header) {
            Ok(config) => planned.push(Planned {
                target_mint: registered.route.target_mint.clone(),
                stock_mint: registered.route.stock_mint.clone(),
                config,
            }),
            // Exactly the routes the production client reports skipping.
            Err(e) => info!("Skipping route: {e:#}"),
        }
    }
    planned
}

/// Replays snapshots from a file through the whole selection path and reports
/// what would have been traded. Never touches the network or the wallet.
pub fn replay(config_path: &str) -> Result<usize> {
    let config = Config::load(config_path)?;
    let feed = config.feed.context("config has no [feed] section")?;
    let path = feed
        .replay_file
        .clone()
        .context("[feed] replay_file is not set")?;
    let snapshots = feed_client::replay_file(Path::new(&path), &feed.settlement_mint)?;
    let mut registry = RouteRegistry::new();
    let mut total = 0;
    for (i, snapshot) in snapshots.iter().enumerate() {
        let planned = plan(&mut registry, snapshot, &feed);
        info!(
            "Snapshot {} ({} routes live): {} tradable",
            i + 1,
            registry.len(),
            planned.len()
        );
        for route in &planned {
            let shape = match &route.stock_mint {
                Some(stock) => format!("stock={stock}"),
                None => "direct".to_string(),
            };
            info!("  would trade {} ({shape})", route.target_mint);
        }
        total += planned.len();
    }
    Ok(total)
}

/// Connects to the feed and trades what it reports. Every transaction still
/// goes through the simulation gate, and the safety defaults keep sending off
/// until the config turns it on.
pub fn run(config_path: &str) -> Result<()> {
    let mut config = Config::load(config_path)?;
    let feed = config
        .feed
        .take()
        .context("config has no [feed] section")?;
    let limits = config.safety.limits();
    let wallet = load_wallet(&config)?;
    info!("Wallet loaded: {}", wallet.pubkey());
    if !config.safety.sending_allowed() {
        info!("Safety: dry run, transactions will be simulated and not sent");
    }

    let rpc = RpcClient::new(config.rpc.url.clone());
    let pipeline = SendPipeline::new(Vec::new(), limits)?;
    let client = FeedClient::from_env(feed_config(&feed))?;

    let runtime = tokio::runtime::Builder::new_multi_thread()
        .worker_threads(2)
        .enable_all()
        .build()?;
    let (tx, mut rx) = mpsc::channel::<Snapshot>(16);
    let settlement_mint = feed.settlement_mint.clone();
    runtime.spawn(client.run(settlement_mint, tx));

    let mut registry = RouteRegistry::new();
    while let Some(snapshot) = runtime.block_on(rx.recv()) {
        for (i, planned) in plan(&mut registry, &snapshot, &feed).into_iter().enumerate() {
            if let Err(e) = trade(&rpc, &wallet, &pipeline, &config, i + 1, &planned) {
                warn!("{}: {e:#}", planned.target_mint);
            }
        }
    }
    Ok(())
}

/// Connects to the feed without loading a wallet or touching RPC. This is the
/// only mode intended for validating vendor feed access.
pub fn probe(config_path: &str) -> Result<()> {
    let config = Config::load(config_path)?;
    let feed = config.feed.context("config has no [feed] section")?;
    let client = FeedClient::from_env(feed_config(&feed))?;
    let runtime = tokio::runtime::Builder::new_current_thread().enable_all().build()?;
    let (tx, mut rx) = mpsc::channel::<Snapshot>(1);
    let settlement_mint = feed.settlement_mint.clone();
    runtime.spawn(client.run(settlement_mint, tx));
    match runtime.block_on(rx.recv()) {
        Some(snapshot) => {
            info!("Feed probe received snapshot: generated_at={} routes={} retention_secs={}", snapshot.generated_at_unix, snapshot.routes.len(), snapshot.retention_secs);
            for route in snapshot.routes.iter().take(feed.limit) {
                info!("Feed route: target={} stock={:?} pools={} max_net_profit={} profitable_tx_count={}", route.target_mint, route.stock_mint, route.pools.len(), route.max_net_profit, route.profitable_tx_count);
            }
            Ok(())
        }
        None => anyhow::bail!("feed closed without a snapshot"),
    }
}

/// Loads one planned route from chain state and offers it to the pipeline.
fn trade(
    rpc: &RpcClient,
    wallet: &Keypair,
    pipeline: &SendPipeline,
    config: &Config,
    index: usize,
    planned: &Planned,
) -> Result<()> {
    let mut loader = AccountLoader::new(rpc);
    let route = Route::resolve(index, &planned.config, &mut loader)?;
    let basket = route.load(&mut loader, wallet.pubkey())?;
    let blockhash = rpc.get_latest_blockhash()?;
    let tx = build_transaction(wallet, &basket, config.bot.compute_unit_price, blockhash)?;
    let outcome = pipeline.dispatch(rpc, &tx)?;
    info!("{}: {outcome:?}", planned.target_mint);
    Ok(())
}

fn load_wallet(config: &Config) -> Result<Keypair> {
    let wallet = config
        .wallet
        .as_ref()
        .context("feed mode needs a [wallet] section")?;
    Keypair::try_from_base58_string(&wallet.private_key)
        .or_else(|_| solana_sdk::signature::read_keypair_file(&wallet.private_key))
        // The value may be the secret itself, so the error never echoes it.
        .map_err(|_| anyhow::anyhow!("wallet.private_key is not a keypair or a keypair file"))
}

fn feed_config(feed: &FeedConfig) -> feed_client::FeedConfig {
    feed_client::FeedConfig {
        endpoint: feed.endpoint.clone(),
        auth: match feed.auth {
            FeedAuth::BearerHeader => Auth::BearerHeader,
            FeedAuth::QueryParam => Auth::QueryParam,
        },
        settlement: feed.settlement.clone(),
        params: feed.selection(),
        snapshot_timeout: Duration::from_secs(feed.snapshot_timeout_secs),
        backoff: Default::default(),
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::observed_feed::parse_snapshot;

    const SOL: &str = "So11111111111111111111111111111111111111112";
    const TARGET: &str = "4k3Dyjzvzp8eMZWUXbBCjEvwSkkk59S5iCNLY3QrkX6R";
    const P1: &str = "CPMMoo8L3F4NbTegBCKVNunggL7H1ZpdTHKxQB5qKP1C";
    const P2: &str = "pAMMBay6oceH9fJKBRHGP5D4bD4sWpmSwMn52FMfXEA";

    fn feed() -> FeedConfig {
        FeedConfig {
            min_profit: 50_000,
            minimum_tx_count: 2,
            ..Default::default()
        }
    }

    fn snapshot_json(profit: u64, txs: u64, pools: &str) -> String {
        format!(
            r#"{{"generated_at_unix":1700000000,"retention_secs":300,"routes":[
               {{"settlement_mint":"{SOL}","target_mint":"{TARGET}",
                 "max_net_profit":{profit},"profitable_tx_count":{txs},
                 "total_net_profit":{profit},"pools":[{pools}]}}]}}"#
        )
    }

    fn two_pools() -> String {
        format!(
            r#"{{"address":"{P1}","dex":"cpmm","token_mint_a":"{TARGET}","token_mint_b":"{SOL}"}},
               {{"address":"{P2}","dex":"pumpswap","token_mint_a":"{SOL}","token_mint_b":"{TARGET}"}}"#
        )
    }

    #[test]
    fn a_profitable_route_becomes_a_transaction_config() {
        let snapshot = parse_snapshot(&snapshot_json(90_000, 5, &two_pools()), SOL).unwrap();
        let mut registry = RouteRegistry::new();
        let planned = plan(&mut registry, &snapshot, &feed());
        assert_eq!(planned.len(), 1);
        assert_eq!(planned[0].target_mint, TARGET);
        assert_eq!(planned[0].config.direct[0].pools.len(), 2);
        assert_eq!(planned[0].config.minimum_profit, 0);
    }

    #[test]
    fn a_route_below_min_profit_never_reaches_the_builder() {
        let snapshot = parse_snapshot(&snapshot_json(10, 5, &two_pools()), SOL).unwrap();
        let mut registry = RouteRegistry::new();
        assert!(plan(&mut registry, &snapshot, &feed()).is_empty());
        assert_eq!(registry.len(), 0);
    }

    #[test]
    fn a_single_pool_route_is_selected_but_not_tradable() {
        let one = format!(
            r#"{{"address":"{P1}","dex":"cpmm","token_mint_a":"{TARGET}","token_mint_b":"{SOL}"}}"#
        );
        let snapshot = parse_snapshot(&snapshot_json(90_000, 5, &one), SOL).unwrap();
        let mut registry = RouteRegistry::new();
        // It passes the profit filters, so it enters the registry, but the
        // builder refuses it: one pool cannot be arbitraged against itself.
        assert!(plan(&mut registry, &snapshot, &feed()).is_empty());
        assert_eq!(registry.len(), 1);
    }

    #[test]
    fn the_header_from_config_reaches_the_built_transaction() {
        let feed = FeedConfig {
            minimum_profit: 60_000,
            flashloan: true,
            ..feed()
        };
        let snapshot = parse_snapshot(&snapshot_json(90_000, 5, &two_pools()), SOL).unwrap();
        let mut registry = RouteRegistry::new();
        let planned = plan(&mut registry, &snapshot, &feed);
        assert_eq!(planned[0].config.minimum_profit, 60_000);
        assert!(planned[0].config.flashloan);
    }

    #[test]
    fn a_vanished_route_leaves_the_plan() {
        let mut registry = RouteRegistry::new();
        let first = parse_snapshot(&snapshot_json(90_000, 5, &two_pools()), SOL).unwrap();
        assert_eq!(plan(&mut registry, &first, &feed()).len(), 1);
        let empty = parse_snapshot(
            r#"{"generated_at_unix":1700000100,"retention_secs":300,"routes":[]}"#,
            SOL,
        )
        .unwrap();
        assert!(plan(&mut registry, &empty, &feed()).is_empty());
        assert_eq!(registry.len(), 0);
    }
}
