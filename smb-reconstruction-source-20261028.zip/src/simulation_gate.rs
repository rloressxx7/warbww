//! The one place a transaction is cleared for sending.
//!
//! Every sender goes through here first. A simulation RPC error and an on-chain
//! execution error are both hard stops: no sender is contacted, so a revert
//! costs nothing.
use solana_client::rpc_client::RpcClient;
use solana_client::rpc_config::RpcSimulateTransactionConfig;
use solana_commitment_config::CommitmentConfig;
use solana_sdk::transaction::VersionedTransaction;
use tracing::{error, info, warn};

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Verdict {
    /// Simulation succeeded; senders may run.
    Pass,
    /// The transaction would fail on chain.
    ExecutionError,
    /// Simulation itself could not be run.
    RpcError,
    /// The gate is disabled by config; nothing was checked.
    Skipped,
}

impl Verdict {
    pub fn may_send(self) -> bool {
        matches!(self, Verdict::Pass | Verdict::Skipped)
    }
}

/// Simulates `tx` once on the read RPC.
///
/// `require_success` is the config switch; turning it off is what the default
/// configuration forbids, and it is logged every time it lets a transaction
/// past unchecked.
pub fn check(
    client: &RpcClient,
    tx: &VersionedTransaction,
    require_success: bool,
) -> Verdict {
    if !require_success {
        warn!("Simulation gate disabled: sending without checking the transaction first");
        return Verdict::Skipped;
    }
    let config = RpcSimulateTransactionConfig {
        sig_verify: true,
        replace_recent_blockhash: false,
        commitment: Some(CommitmentConfig::processed()),
        ..Default::default()
    };
    match client.simulate_transaction_with_config(tx, config) {
        Ok(result) if result.value.err.is_none() => {
            info!("Transaction simulation passed");
            Verdict::Pass
        }
        Ok(result) => {
            error!(
                "Transaction blocked: simulation returned an execution error: {:?}",
                result.value.err
            );
            Verdict::ExecutionError
        }
        Err(e) => {
            error!("Transaction blocked: simulation RPC failed: {e}");
            Verdict::RpcError
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn only_pass_and_skip_may_send() {
        assert!(Verdict::Pass.may_send());
        assert!(Verdict::Skipped.may_send());
        assert!(!Verdict::ExecutionError.may_send());
        assert!(!Verdict::RpcError.may_send());
    }
}
