use crate::v10::{SOL, USDC};
use anyhow::Context;
use serde::{de::Error, Deserialize, Deserializer};
use solana_sdk::pubkey::Pubkey;
use std::{env, fs, str::FromStr};

#[derive(Debug, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct Config {
    pub rpc: RpcConfig,
    /// Not needed for an offline replay, which never signs anything.
    #[serde(default)]
    pub wallet: Option<WalletConfig>,
    #[serde(default)]
    pub bot: BotConfig,
    /// Present when routes come from the observed-arb feed instead of
    /// `[[transactions]]`.
    #[serde(default)]
    pub feed: Option<FeedConfig>,
    /// Left out, the safe defaults apply: simulate and report, send nothing.
    #[serde(default)]
    pub safety: SafetyConfig,
    /// Static routes. Empty when `[feed]` supplies them instead.
    #[serde(default)]
    pub transactions: Vec<TransactionConfig>,
}

/// The observed-arb feed. The credential is never configured here: it is read
/// from `OBSERVED_ARB_TOKEN` at startup.
#[derive(Debug, Deserialize)]
#[serde(deny_unknown_fields, default)]
pub struct FeedConfig {
    pub endpoint: String,
    pub auth: FeedAuth,
    /// What the subscription calls the settlement, e.g. `sol`.
    pub settlement: String,
    /// The same settlement as a mint address, which snapshots are checked against.
    pub settlement_mint: String,
    pub min_profit: u64,
    pub minimum_tx_count: u64,
    pub within_secs: u64,
    pub limit: usize,
    pub snapshot_timeout_secs: u64,
    /// Replays snapshots from this file instead of connecting. Nothing is
    /// signed or sent in replay mode.
    pub replay_file: Option<String>,
    /// Profit floor written into each built transaction's header.
    pub minimum_profit: u64,
    pub flashloan: bool,
    pub no_failure: bool,
    pub trade_size: u64,
}

#[derive(Debug, Clone, Copy, Deserialize, PartialEq, Eq)]
#[serde(rename_all = "snake_case")]
pub enum FeedAuth {
    BearerHeader,
    QueryParam,
}

impl Default for FeedConfig {
    fn default() -> Self {
        Self {
            endpoint: crate::feed_client::DEFAULT_ENDPOINT.to_string(),
            auth: FeedAuth::BearerHeader,
            settlement: "sol".to_string(),
            settlement_mint: SOL.to_string(),
            min_profit: 0,
            minimum_tx_count: 2,
            within_secs: 300,
            limit: 10,
            snapshot_timeout_secs: 30,
            replay_file: None,
            minimum_profit: 0,
            flashloan: false,
            no_failure: false,
            trade_size: 0,
        }
    }
}

impl FeedConfig {
    pub fn selection(&self) -> crate::selector::SelectionParams {
        crate::selector::SelectionParams {
            min_profit: self.min_profit,
            minimum_tx_count: self.minimum_tx_count,
            within_secs: self.within_secs,
            limit: self.limit,
        }
    }

    pub fn header(&self) -> crate::route_builder::Header {
        crate::route_builder::Header {
            minimum_profit: self.minimum_profit,
            flashloan: self.flashloan,
            no_failure: self.no_failure,
            trade_size: self.trade_size,
        }
    }
}

/// The limits every send passes through. Each default is the cautious value,
/// so a config that omits this section cannot spend anything.
#[derive(Debug, Deserialize)]
#[serde(deny_unknown_fields, default)]
pub struct SafetyConfig {
    /// Build and simulate, then stop instead of sending.
    pub dry_run: bool,
    /// Nothing is sent at all while this is false.
    pub send_enabled: bool,
    /// Only send after a simulation that succeeded.
    pub require_simulation_success: bool,
    /// Preflight at the sender as well.
    pub skip_preflight: bool,
    pub max_send_per_minute: u32,
    pub max_tip_lamports: u64,
}

impl Default for SafetyConfig {
    fn default() -> Self {
        Self {
            dry_run: true,
            send_enabled: false,
            require_simulation_success: true,
            skip_preflight: false,
            max_send_per_minute: 1,
            max_tip_lamports: 1_000_000,
        }
    }
}

impl SafetyConfig {
    pub fn limits(&self) -> crate::senders::Limits {
        crate::senders::Limits {
            send_enabled: self.send_enabled,
            dry_run: self.dry_run,
            require_simulation_success: self.require_simulation_success,
            skip_preflight: self.skip_preflight,
            max_send_per_minute: self.max_send_per_minute,
            max_tip_lamports: self.max_tip_lamports,
        }
    }

    /// True when this configuration is allowed to put a transaction on chain.
    pub fn sending_allowed(&self) -> bool {
        self.send_enabled && !self.dry_run
    }
}

#[derive(Debug, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct RpcConfig {
    #[serde(deserialize_with = "string_or_env")]
    pub url: String,
    /// Where transactions are sent; `url` when empty.
    #[serde(default)]
    pub send_urls: Vec<String>,
}

#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
pub struct WalletConfig {
    #[serde(deserialize_with = "string_or_env")]
    pub private_key: String,
}

impl std::fmt::Debug for WalletConfig {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.debug_struct("WalletConfig")
            .field("private_key", &"<redacted>")
            .finish()
    }
}

#[derive(Debug, Deserialize)]
#[serde(deny_unknown_fields, default)]
pub struct BotConfig {
    /// Delay between sends of each transaction.
    pub process_delay_ms: u64,
    /// Priority fee in microlamports per CU.
    pub compute_unit_price: u64,
    /// Retries each RPC makes for each send.
    pub max_retries: usize,
}

impl Default for BotConfig {
    fn default() -> Self {
        Self {
            process_delay_ms: 400,
            compute_unit_price: 1000,
            max_retries: 3,
        }
    }
}

/// One V10 instruction: its header options and the route groups it trades.
#[derive(Debug, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct TransactionConfig {
    pub settlement: Settlement,
    /// Borrow the trade from the program's vault instead of the wallet.
    #[serde(default)]
    pub flashloan: bool,
    /// Profit, in settlement-mint base units, below which the trade fails.
    #[serde(default)]
    pub minimum_profit: u64,
    /// Fixed input in settlement-mint base units; 0 lets the program search.
    #[serde(default)]
    pub trade_size: u64,
    /// Succeed without trading when there is no profit, instead of failing.
    #[serde(default)]
    pub no_failure: bool,
    /// Price the SOL/USDC conversion at its quoted rate instead of its curve.
    #[serde(default)]
    pub constant_conversion: bool,
    pub additional_fee: Option<AdditionalFee>,
    #[serde(default)]
    pub direct: Vec<DirectConfig>,
    #[serde(default)]
    pub triangle: Vec<TriangleConfig>,
}

#[derive(Clone, Copy, Debug, Deserialize, PartialEq, Eq)]
pub enum Settlement {
    #[serde(rename = "SOL")]
    Sol,
    #[serde(rename = "USDC")]
    Usdc,
}

impl Settlement {
    pub fn mint(self) -> Pubkey {
        match self {
            Self::Sol => SOL,
            Self::Usdc => USDC,
        }
    }
}

/// A share of the profit above `minimum_profit` paid to a third party.
#[derive(Debug, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct AdditionalFee {
    pub bps: u16,
    /// Settlement-mint token account that receives the fee.
    #[serde(deserialize_with = "pubkey")]
    pub collector: Pubkey,
}

/// Pools trading one token against SOL or USDC.
#[derive(Debug, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct DirectConfig {
    #[serde(deserialize_with = "pubkeys")]
    pub pools: Vec<Pubkey>,
}

/// A token, a second token it trades against, and SOL or USDC.
#[derive(Debug, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct TriangleConfig {
    /// Trades the target against the stock.
    #[serde(deserialize_with = "pubkey")]
    pub intermediate: Pubkey,
    /// Trade the stock against SOL or USDC.
    #[serde(deserialize_with = "pubkeys")]
    pub bridges: Vec<Pubkey>,
    /// Trade the target against the settlement mint.
    #[serde(deserialize_with = "pubkeys")]
    pub direct: Vec<Pubkey>,
}

/// The value, or the environment variable it names as `$NAME`.
fn string_or_env<'de, D: Deserializer<'de>>(deserializer: D) -> Result<String, D::Error> {
    let value = String::deserialize(deserializer)?;
    match value.strip_prefix('$') {
        Some(name) => env::var(name)
            .map_err(|_| D::Error::custom(format!("environment variable `{name}` is not set"))),
        None => Ok(value),
    }
}

fn parse_pubkey<E: Error>(value: &str) -> Result<Pubkey, E> {
    Pubkey::from_str(value).map_err(|e| E::custom(format!("invalid address `{value}`: {e}")))
}

fn pubkey<'de, D: Deserializer<'de>>(deserializer: D) -> Result<Pubkey, D::Error> {
    parse_pubkey(&String::deserialize(deserializer)?)
}

fn pubkeys<'de, D: Deserializer<'de>>(deserializer: D) -> Result<Vec<Pubkey>, D::Error> {
    Vec::<String>::deserialize(deserializer)?
        .iter()
        .map(|value| parse_pubkey(value))
        .collect()
}

impl Config {
    pub fn load(path: &str) -> anyhow::Result<Self> {
        let contents =
            fs::read_to_string(path).with_context(|| format!("Failed to read config {path}"))?;
        Ok(toml::from_str(&contents)?)
    }
}
