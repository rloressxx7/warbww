//! Compatibility layer for the observed-quote-arbs snapshot feed.
use anyhow::{bail, Context, Result};
use serde::Deserialize;

#[derive(Debug, Clone, Deserialize)]
pub struct Snapshot {
    #[serde(default)]
    pub bundles: Vec<serde_json::Value>,
    #[serde(default)]
    pub companions: Vec<serde_json::Value>,
    pub generated_at_unix: u64,
    #[serde(default)]
    pub retention_secs: u64,
    #[serde(default)]
    pub routes: Vec<ObservedRoute>,
}
#[derive(Debug, Clone, Deserialize)]
pub struct ObservedRoute {
    #[serde(default)]
    pub copy_rate: Option<f64>,
    #[serde(default)]
    pub fees: RouteFees,
    #[serde(default)]
    pub lookup_tables: Vec<String>,
    #[serde(default)]
    pub max_net_profit: u64,
    #[serde(default)]
    pub pools: Vec<ObservedPool>,
    #[serde(default)]
    pub profitable_tx_count: u64,
    pub settlement_mint: String,
    #[serde(default)]
    pub stock_mint: Option<String>,
    pub target_mint: String,
    #[serde(default)]
    pub total_net_profit: u64,
}
#[derive(Debug, Clone, Default, Deserialize)]
pub struct RouteFees {
    #[serde(default)]
    pub compute_unit_price_micro_lamports: FeePercentiles,
    #[serde(default)]
    pub observations: u64,
    #[serde(default)]
    pub tip_lamports: FeePercentiles,
    #[serde(default)]
    pub tipped_observations: u64,
}
#[derive(Debug, Clone, Default, Deserialize)]
pub struct FeePercentiles {
    #[serde(default)]
    pub p10: u64,
    #[serde(default)]
    pub p25: u64,
    #[serde(default)]
    pub p50: u64,
    #[serde(default)]
    pub p75: u64,
    #[serde(default)]
    pub p90: u64,
    #[serde(default)]
    pub max: u64,
}
#[derive(Debug, Clone, Deserialize)]
pub struct ObservedPool {
    pub address: String,
    pub dex: String,
    #[serde(default)]
    pub lookup_tables: Vec<String>,
    #[serde(default)]
    pub max_net_profit: u64,
    #[serde(default)]
    pub profitable_tx_count: u64,
    #[serde(default)]
    pub role: String,
    #[serde(default)]
    pub token_mint_a: Option<String>,
    #[serde(default)]
    pub token_mint_b: Option<String>,
    #[serde(default)]
    pub total_net_profit: u64,
}
pub fn parse_snapshot(text: &str, expected_settlement: &str) -> Result<Snapshot> {
    let snapshot: Snapshot = serde_json::from_str(text).context("invalid observed-arb JSON")?;
    if snapshot.generated_at_unix == 0 {
        bail!("observed-arb snapshot has no generation timestamp");
    }
    for route in &snapshot.routes {
        if route.settlement_mint != expected_settlement {
            bail!("observed route settlement differs from subscription");
        }
        if route.pools.is_empty() {
            bail!("observed route has no pools");
        }
        if route.stock_mint.is_some() && route.target_mint == route.settlement_mint {
            bail!("stock route target equals settlement");
        }
    }
    Ok(snapshot)
}
