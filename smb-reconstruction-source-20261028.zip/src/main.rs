use clap::{Parser, ValueEnum};
use tracing::{info, Level};

/// A simplified Solana onchain arbitrage bot
#[derive(Parser)]
#[command(version)]
struct Args {
    /// Config file
    #[arg(short, long, value_name = "FILE", default_value = "config.toml")]
    config: String,
    /// Where routes come from, and whether anything may be sent.
    #[arg(short, long, value_enum, default_value_t = Mode::Static)]
    mode: Mode,
}

#[derive(Clone, Copy, ValueEnum)]
enum Mode {
    /// Trade the routes written in `[[transactions]]`.
    Static,
    /// Trade the routes the observed-arb feed reports.
    Feed,
    /// Run recorded snapshots through selection and report what would trade.
    /// Offline: no RPC, no wallet, nothing sent.
    Replay,
    /// Connect to the feed and print only sanitized snapshot summaries.
    /// No wallet, RPC, transaction, or sender is used.
    FeedProbe,
}

fn main() -> anyhow::Result<()> {
    tracing_subscriber::fmt().with_max_level(Level::INFO).init();
    let args = Args::parse();
    info!("Using config file: {}", args.config);
    match args.mode {
        Mode::Static => solana_onchain_arbitrage_bot::bot::run_bot(&args.config),
        Mode::Feed => solana_onchain_arbitrage_bot::runtime::run(&args.config),
        Mode::Replay => {
            let tradable = solana_onchain_arbitrage_bot::runtime::replay(&args.config)?;
            info!("Replay finished: {tradable} tradable route(s) across all snapshots");
            Ok(())
        }
        Mode::FeedProbe => solana_onchain_arbitrage_bot::runtime::probe(&args.config),
    }
}
