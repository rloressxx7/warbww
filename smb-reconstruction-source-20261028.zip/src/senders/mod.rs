//! Transaction senders, and the limits every send passes through.
//!
//! All four vendors speak JSON-RPC over HTTPS and differ only in endpoint,
//! auth header and method, so they share one implementation rather than four
//! near-identical ones. Nothing here sends until [`SendPipeline::dispatch`] has
//! cleared the transaction with [`crate::simulation_gate`].
use crate::simulation_gate::{self, Verdict};
use anyhow::{bail, Context, Result};
use base64::Engine;
use solana_client::rpc_client::RpcClient;
use solana_sdk::transaction::VersionedTransaction;
use std::collections::VecDeque;
use std::sync::Mutex;
use std::time::{Duration, Instant};
use tracing::{info, warn};

/// A credential that never reaches a log.
#[derive(Clone, Default)]
pub struct Secret(String);

impl Secret {
    pub fn new(value: impl Into<String>) -> Self {
        Self(value.into())
    }

    /// Reads the value from an environment variable, so it is never written in
    /// a config file that gets shared or committed.
    pub fn from_env(name: &str) -> Result<Self> {
        let value = std::env::var(name)
            .with_context(|| format!("environment variable `{name}` is not set"))?;
        if value.trim().is_empty() {
            bail!("environment variable `{name}` is empty");
        }
        Ok(Self(value))
    }

    pub fn expose(&self) -> &str {
        &self.0
    }

    pub fn is_empty(&self) -> bool {
        self.0.is_empty()
    }
}

impl std::fmt::Debug for Secret {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.write_str("<redacted>")
    }
}

impl std::fmt::Display for Secret {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.write_str("<redacted>")
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum SenderKind {
    /// Any plain Solana JSON-RPC endpoint.
    JsonRpc,
    /// Jito block engine: a one-transaction bundle.
    Jito,
    /// NextBlock's own submit endpoint.
    NextBlock,
    /// Astralane iris: JSON-RPC `sendTransaction` behind an api key.
    Astralane,
}

impl SenderKind {
    fn method(self) -> &'static str {
        match self {
            Self::Jito => "sendBundle",
            _ => "sendTransaction",
        }
    }
}

/// How fast and how expensively any one sender may send.
#[derive(Debug, Clone, Copy)]
pub struct Limits {
    /// Nothing is sent at all while this is false.
    pub send_enabled: bool,
    /// Build and simulate, then stop and log instead of sending.
    pub dry_run: bool,
    /// A transaction is only sent after a successful simulation.
    pub require_simulation_success: bool,
    /// Preflight stays on at the sender as well.
    pub skip_preflight: bool,
    pub max_send_per_minute: u32,
    pub max_tip_lamports: u64,
}

/// The defaults are the safe ones: a freshly configured bot simulates and
/// reports, and sends nothing.
impl Default for Limits {
    fn default() -> Self {
        Self {
            send_enabled: false,
            dry_run: true,
            require_simulation_success: true,
            skip_preflight: false,
            max_send_per_minute: 1,
            max_tip_lamports: 1_000_000,
        }
    }
}

/// A sliding one-minute window.
#[derive(Debug)]
struct RateLimiter {
    per_minute: u32,
    sent: Mutex<VecDeque<Instant>>,
}

impl RateLimiter {
    fn new(per_minute: u32) -> Self {
        Self {
            per_minute,
            sent: Mutex::new(VecDeque::new()),
        }
    }

    /// Records a send and reports whether it was allowed.
    fn try_acquire(&self) -> bool {
        let mut sent = self.sent.lock().unwrap();
        let now = Instant::now();
        while sent
            .front()
            .is_some_and(|t| now.duration_since(*t) >= Duration::from_secs(60))
        {
            sent.pop_front();
        }
        if sent.len() as u32 >= self.per_minute {
            return false;
        }
        sent.push_back(now);
        true
    }
}

#[derive(Debug)]
pub struct Sender {
    pub name: String,
    pub kind: SenderKind,
    pub url: String,
    /// Header carrying `auth_value`; vendors that take the key in the URL
    /// leave this unset.
    pub auth_header: Option<String>,
    pub auth_value: Secret,
    /// The tip this sender is configured to attach, checked against
    /// [`Limits::max_tip_lamports`] before anything is sent.
    pub tip_lamports: u64,
    limiter: RateLimiter,
}

impl Sender {
    pub fn new(
        name: impl Into<String>,
        kind: SenderKind,
        url: impl Into<String>,
        tip_lamports: u64,
        max_send_per_minute: u32,
    ) -> Self {
        Self {
            name: name.into(),
            kind,
            url: url.into(),
            auth_header: None,
            auth_value: Secret::default(),
            tip_lamports,
            limiter: RateLimiter::new(max_send_per_minute),
        }
    }

    pub fn with_auth(mut self, header: Option<&str>, value: Secret) -> Self {
        self.auth_header = header.map(str::to_owned);
        self.auth_value = value;
        self
    }

    /// The JSON-RPC body this vendor expects for one signed transaction.
    fn body(&self, encoded: &str) -> serde_json::Value {
        let params = match self.kind {
            // A bundle is a list of transactions; we send exactly one.
            SenderKind::Jito => serde_json::json!([[encoded], {"encoding": "base64"}]),
            SenderKind::NextBlock => serde_json::json!({
                "transaction": {"content": encoded},
                "frontRunningProtection": true,
            }),
            _ => serde_json::json!([
                encoded,
                {"encoding": "base64", "skipPreflight": false}
            ]),
        };
        serde_json::json!({
            "jsonrpc": "2.0",
            "id": 1,
            "method": self.kind.method(),
            "params": params,
        })
    }

    /// Posts an already-cleared transaction. Errors never include the URL,
    /// because a vendor key may be a query parameter in it.
    fn post(&self, client: &reqwest::blocking::Client, encoded: &str) -> Result<String> {
        let mut request = client.post(&self.url).json(&self.body(encoded));
        if let Some(header) = &self.auth_header {
            request = request.header(header.as_str(), self.auth_value.expose());
        }
        let response = request
            .send()
            .map_err(|e| anyhow::anyhow!("{}: request failed: {}", self.name, redact(&e)))?;
        let status = response.status();
        let text = response.text().unwrap_or_default();
        if !status.is_success() {
            bail!("{}: HTTP {}: {}", self.name, status.as_u16(), truncate(&text));
        }
        Ok(truncate(&text))
    }
}

/// Keeps a vendor key out of an error message when it sits in the URL.
fn redact(error: &reqwest::Error) -> String {
    let text = error.to_string();
    match text.find("api-key=") {
        Some(i) => format!("{}api-key=<redacted>", &text[..i]),
        None => text,
    }
}

fn truncate(text: &str) -> String {
    text.chars().take(200).collect()
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum Outcome {
    /// Cleared, but sending is off: nothing left the process.
    DryRun,
    /// The simulation gate refused it.
    Blocked(String),
    /// Per-sender results, successes first in the order they were tried.
    Sent { ok: Vec<String>, failed: Vec<String> },
}

#[derive(Debug)]
pub struct SendPipeline {
    senders: Vec<Sender>,
    limits: Limits,
    http: reqwest::blocking::Client,
}

impl SendPipeline {
    pub fn new(senders: Vec<Sender>, limits: Limits) -> Result<Self> {
        for sender in &senders {
            if sender.tip_lamports > limits.max_tip_lamports {
                bail!(
                    "sender `{}` is configured to tip {} lamports, above the {} lamport cap",
                    sender.name,
                    sender.tip_lamports,
                    limits.max_tip_lamports
                );
            }
            if sender.auth_header.is_some() && sender.auth_value.is_empty() {
                bail!("sender `{}` sets an auth header with no value", sender.name);
            }
        }
        Ok(Self {
            senders,
            limits,
            http: reqwest::blocking::Client::builder()
                .timeout(Duration::from_secs(10))
                .build()
                .context("failed to build the sender HTTP client")?,
        })
    }

    pub fn limits(&self) -> &Limits {
        &self.limits
    }

    /// Simulates, then sends through every sender that is still inside its
    /// rate limit. The gate runs exactly once, before the first sender.
    pub fn dispatch(
        &self,
        simulation_client: &RpcClient,
        tx: &VersionedTransaction,
    ) -> Result<Outcome> {
        let verdict = simulation_gate::check(
            simulation_client,
            tx,
            self.limits.require_simulation_success,
        );
        if !verdict.may_send() {
            return Ok(Outcome::Blocked(format!("{verdict:?}")));
        }
        if !self.limits.send_enabled || self.limits.dry_run {
            info!(
                "Dry run: transaction {} cleared simulation and was not sent",
                tx.signatures.first().copied().unwrap_or_default()
            );
            return Ok(Outcome::DryRun);
        }
        let encoded =
            base64::engine::general_purpose::STANDARD.encode(bincode::serialize(tx)?);
        let mut ok = Vec::new();
        let mut failed = Vec::new();
        for sender in &self.senders {
            if !sender.limiter.try_acquire() {
                warn!("{}: rate limit reached, skipping this send", sender.name);
                failed.push(format!("{}: rate limited", sender.name));
                continue;
            }
            match sender.post(&self.http, &encoded) {
                Ok(response) => {
                    info!("{}: accepted the transaction", sender.name);
                    ok.push(format!("{}: {response}", sender.name));
                }
                Err(e) => {
                    warn!("{e:#}");
                    failed.push(e.to_string());
                }
            }
        }
        Ok(Outcome::Sent { ok, failed })
    }
}

/// Whether `verdict` alone would let a send happen, for callers that gate
/// without a pipeline.
pub fn cleared(verdict: Verdict) -> bool {
    verdict.may_send()
}

#[cfg(test)]
mod tests {
    use super::*;

    fn sender(kind: SenderKind, tip: u64, per_minute: u32) -> Sender {
        Sender::new("test", kind, "https://example.invalid/", tip, per_minute)
    }

    #[test]
    fn defaults_send_nothing() {
        let limits = Limits::default();
        assert!(!limits.send_enabled);
        assert!(limits.dry_run);
        assert!(limits.require_simulation_success);
        assert!(!limits.skip_preflight);
        assert_eq!(limits.max_send_per_minute, 1);
        assert_eq!(limits.max_tip_lamports, 1_000_000);
    }

    #[test]
    fn tip_above_the_cap_is_refused_at_construction() {
        let err = SendPipeline::new(
            vec![sender(SenderKind::Astralane, 2_000_000, 1)],
            Limits::default(),
        )
        .unwrap_err()
        .to_string();
        assert!(err.contains("above the"), "{err}");
    }

    #[test]
    fn auth_header_without_a_value_is_refused() {
        let s = sender(SenderKind::Astralane, 1, 1).with_auth(Some("api_key"), Secret::default());
        let err = SendPipeline::new(vec![s], Limits::default())
            .unwrap_err()
            .to_string();
        assert!(err.contains("no value"), "{err}");
    }

    #[test]
    fn rate_limiter_allows_exactly_its_budget() {
        let limiter = RateLimiter::new(2);
        assert!(limiter.try_acquire());
        assert!(limiter.try_acquire());
        assert!(!limiter.try_acquire());
    }

    #[test]
    fn secrets_never_render() {
        let secret = Secret::new("super-secret-token");
        assert_eq!(format!("{secret:?}"), "<redacted>");
        assert_eq!(format!("{secret}"), "<redacted>");
        let s = sender(SenderKind::Astralane, 1, 1).with_auth(Some("api_key"), secret);
        let rendered = format!("{s:?}");
        assert!(!rendered.contains("super-secret-token"), "{rendered}");
    }

    #[test]
    fn jito_sends_a_bundle_and_others_send_a_transaction() {
        let bundle = sender(SenderKind::Jito, 1, 1).body("AAAA");
        assert_eq!(bundle["method"], "sendBundle");
        assert_eq!(bundle["params"][0][0], "AAAA");

        let single = sender(SenderKind::Astralane, 1, 1).body("AAAA");
        assert_eq!(single["method"], "sendTransaction");
        assert_eq!(single["params"][0], "AAAA");
        assert_eq!(single["params"][1]["skipPreflight"], false);

        let next = sender(SenderKind::NextBlock, 1, 1).body("AAAA");
        assert_eq!(next["params"]["transaction"]["content"], "AAAA");
    }

    #[test]
    fn blocked_verdicts_stop_the_send() {
        assert!(!cleared(Verdict::ExecutionError));
        assert!(!cleared(Verdict::RpcError));
        assert!(cleared(Verdict::Pass));
    }
}
