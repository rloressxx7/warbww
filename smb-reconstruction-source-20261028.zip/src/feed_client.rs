//! The observed-arb websocket client.
//!
//! The endpoint rejects anonymous clients, so the token comes from the
//! environment and is never written to a config file or a log. Nothing in this
//! module reads the production binary's own credential.
use crate::observed_feed::{parse_snapshot, Snapshot};
use crate::selector::SelectionParams;
use crate::senders::Secret;
use anyhow::{bail, Context, Result};
use futures_util::{SinkExt, StreamExt};
use std::path::Path;
use std::time::Duration;
use tokio::sync::mpsc;
use tokio_tungstenite::tungstenite::client::IntoClientRequest;
use tokio_tungstenite::tungstenite::Message;
use tracing::{info, warn};

pub const DEFAULT_ENDPOINT: &str = "ws://api.solanamevbot.com/observed-quote-arbs";
/// The environment variable holding the feed credential.
pub const TOKEN_ENV: &str = "OBSERVED_ARB_TOKEN";

/// How the endpoint wants the credential. The production client's exact
/// handshake is not known, so both common forms are available.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Auth {
    /// `Authorization: Bearer <token>`.
    BearerHeader,
    /// `?token=<token>` appended to the endpoint.
    QueryParam,
}

#[derive(Debug, Clone)]
pub struct FeedConfig {
    pub endpoint: String,
    pub auth: Auth,
    /// Settlement mint the subscription asks for, e.g. `sol`.
    pub settlement: String,
    pub params: SelectionParams,
    /// Giving up on a silent connection and reconnecting.
    pub snapshot_timeout: Duration,
    pub backoff: Backoff,
}

impl Default for FeedConfig {
    fn default() -> Self {
        Self {
            endpoint: DEFAULT_ENDPOINT.to_string(),
            auth: Auth::BearerHeader,
            settlement: "sol".to_string(),
            params: SelectionParams::default(),
            snapshot_timeout: Duration::from_secs(30),
            backoff: Backoff::default(),
        }
    }
}

/// Exponential backoff between reconnects.
#[derive(Debug, Clone, Copy)]
pub struct Backoff {
    pub initial: Duration,
    pub max: Duration,
    attempt: u32,
}

impl Default for Backoff {
    fn default() -> Self {
        Self {
            initial: Duration::from_secs(1),
            max: Duration::from_secs(60),
            attempt: 0,
        }
    }
}

impl Backoff {
    /// The next wait, doubling each time up to `max`.
    pub fn next_delay(&mut self) -> Duration {
        let delay = self
            .initial
            .saturating_mul(1u32 << self.attempt.min(16))
            .min(self.max);
        self.attempt = self.attempt.saturating_add(1);
        delay
    }

    /// Called once a connection works, so the next outage starts over.
    pub fn reset(&mut self) {
        self.attempt = 0;
    }
}

/// The message asking the feed for one settlement mint's routes. The field
/// names are the ones the production client reports on connect.
pub fn subscription_message(settlement: &str, params: &SelectionParams) -> serde_json::Value {
    serde_json::json!({
        "settlement": settlement,
        "min_profit": params.min_profit,
        "minimum_tx_count": params.minimum_tx_count,
        "within_secs": params.within_secs,
        "limit": params.limit,
    })
}

/// One frame from the feed. Anything else is refused rather than guessed at.
pub fn parse_message(text: &str, expected_settlement_mint: &str) -> Result<Snapshot> {
    let value: serde_json::Value =
        serde_json::from_str(text).context("invalid observed-quote-arbs snapshot")?;
    if let Some(kind) = value.get("type").and_then(|t| t.as_str()) {
        if kind != "snapshot" {
            bail!("unsupported observed-arb message type: {kind}");
        }
        let payload = value
            .get("data")
            .or_else(|| value.get("snapshot"))
            .context("snapshot message carries no payload")?;
        return parse_snapshot(&payload.to_string(), expected_settlement_mint);
    }
    parse_snapshot(text, expected_settlement_mint)
}

/// Reads snapshots from a file for offline replay: either one JSON array of
/// snapshots, or one snapshot per line.
pub fn replay_file(path: &Path, expected_settlement_mint: &str) -> Result<Vec<Snapshot>> {
    let text = std::fs::read_to_string(path)
        .with_context(|| format!("failed to read replay file {}", path.display()))?;
    let trimmed = text.trim_start();
    if trimmed.starts_with('[') {
        let frames: Vec<serde_json::Value> =
            serde_json::from_str(trimmed).context("invalid replay array")?;
        return frames
            .iter()
            .map(|frame| parse_message(&frame.to_string(), expected_settlement_mint))
            .collect();
    }
    text.lines()
        .filter(|line| !line.trim().is_empty())
        .map(|line| parse_message(line, expected_settlement_mint))
        .collect()
}

pub struct FeedClient {
    config: FeedConfig,
    token: Secret,
}

impl FeedClient {
    /// Takes the credential from the environment. The value is never logged,
    /// and never appears in an error.
    pub fn from_env(config: FeedConfig) -> Result<Self> {
        Ok(Self {
            token: Secret::from_env(TOKEN_ENV)?,
            config,
        })
    }

    pub fn with_token(config: FeedConfig, token: Secret) -> Self {
        Self { config, token }
    }

    fn request(&self) -> Result<tokio_tungstenite::tungstenite::handshake::client::Request> {
        let url = match self.config.auth {
            Auth::QueryParam => {
                let separator = if self.config.endpoint.contains('?') { '&' } else { '?' };
                format!(
                    "{}{separator}token={}",
                    self.config.endpoint,
                    self.token.expose()
                )
            }
            Auth::BearerHeader => self.config.endpoint.clone(),
        };
        let mut request = url
            .into_client_request()
            .map_err(|_| anyhow::anyhow!("feed endpoint is not a valid websocket URL"))?;
        if self.config.auth == Auth::BearerHeader {
            let value = format!("Bearer {}", self.token.expose())
                .parse()
                .map_err(|_| anyhow::anyhow!("feed token is not a valid header value"))?;
            request.headers_mut().insert("Authorization", value);
        }
        Ok(request)
    }

    /// Connects, subscribes and forwards every snapshot until the connection
    /// drops, then reconnects with backoff. Runs until `out` is closed.
    pub async fn run(mut self, settlement_mint: String, out: mpsc::Sender<Snapshot>) {
        loop {
            match self.session(&settlement_mint, &out).await {
                Ok(()) => {
                    info!("Observed-arb feed closed by the server; reconnecting");
                    self.config.backoff.reset();
                }
                // Errors never carry the token: `request()` keeps it out.
                Err(e) => warn!("Observed-arb feed failed: {e:#}"),
            }
            if out.is_closed() {
                return;
            }
            let delay = self.config.backoff.next_delay();
            info!("Reconnecting to the observed-arb feed in {delay:?}");
            tokio::time::sleep(delay).await;
        }
    }

    async fn session(&mut self, settlement_mint: &str, out: &mpsc::Sender<Snapshot>) -> Result<()> {
        let (mut stream, _) = tokio_tungstenite::connect_async(self.request()?)
            .await
            .map_err(|e| anyhow::anyhow!("websocket connect failed: {}", strip_token(e)))?;
        self.config.backoff.reset();
        let subscribe =
            subscription_message(&self.config.settlement, &self.config.params).to_string();
        stream.send(Message::Text(subscribe.into())).await?;
        info!(
            "Observed-arb market selection connected (min_profit={} settlement={} \
             minimum_tx_count={} within_secs={} limit={})",
            self.config.params.min_profit,
            self.config.settlement,
            self.config.params.minimum_tx_count,
            self.config.params.within_secs,
            self.config.params.limit
        );
        loop {
            let frame = tokio::time::timeout(self.config.snapshot_timeout, stream.next()).await;
            let message = match frame {
                Err(_) => bail!(
                    "no snapshot within {:?}; dropping the connection",
                    self.config.snapshot_timeout
                ),
                Ok(None) => return Ok(()),
                Ok(Some(message)) => message?,
            };
            match message {
                Message::Text(text) => match parse_message(&text, settlement_mint) {
                    Ok(snapshot) => {
                        if out.send(snapshot).await.is_err() {
                            return Ok(());
                        }
                    }
                    // One bad frame is not worth dropping a working connection.
                    Err(e) => warn!("Discarding a feed message: {e:#}"),
                },
                Message::Ping(payload) => stream.send(Message::Pong(payload)).await?,
                Message::Close(_) => return Ok(()),
                _ => {}
            }
        }
    }
}

/// Keeps a token out of a connection error that echoed the URL back.
fn strip_token(error: impl std::fmt::Display) -> String {
    let text = error.to_string();
    match text.find("token=") {
        Some(i) => format!("{}token=<redacted>", &text[..i]),
        None => text,
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    const SOL: &str = "So11111111111111111111111111111111111111112";

    fn snapshot_json(settlement: &str) -> String {
        format!(
            r#"{{"generated_at_unix":1700000000,"retention_secs":300,"routes":[
                {{"settlement_mint":"{settlement}","target_mint":"T","max_net_profit":90000,
                  "profitable_tx_count":5,"total_net_profit":90000,
                  "pools":[{{"address":"P","dex":"pumpswap"}}]}}]}}"#
        )
    }

    #[test]
    fn parses_a_plain_snapshot() {
        let snapshot = parse_message(&snapshot_json(SOL), SOL).unwrap();
        assert_eq!(snapshot.routes.len(), 1);
        assert_eq!(snapshot.routes[0].max_net_profit, 90_000);
    }

    #[test]
    fn rejects_broken_json() {
        let err = parse_message("{not json", SOL).unwrap_err().to_string();
        assert!(err.contains("invalid observed-quote-arbs snapshot"), "{err}");
    }

    #[test]
    fn rejects_a_settlement_mismatch() {
        let err = parse_message(&snapshot_json("OTHER"), SOL)
            .unwrap_err()
            .to_string();
        assert!(err.contains("settlement"), "{err}");
    }

    #[test]
    fn rejects_an_unknown_message_type() {
        let err = parse_message(r#"{"type":"heartbeat"}"#, SOL)
            .unwrap_err()
            .to_string();
        assert!(err.contains("unsupported observed-arb message type"), "{err}");
    }

    #[test]
    fn unwraps_a_typed_snapshot() {
        let wrapped = format!(r#"{{"type":"snapshot","data":{}}}"#, snapshot_json(SOL));
        assert_eq!(parse_message(&wrapped, SOL).unwrap().routes.len(), 1);
    }

    #[test]
    fn subscription_carries_every_filter() {
        let params = SelectionParams {
            min_profit: 50_000,
            minimum_tx_count: 2,
            within_secs: 300,
            limit: 10,
        };
        let message = subscription_message("sol", &params);
        assert_eq!(message["min_profit"], 50_000);
        assert_eq!(message["settlement"], "sol");
        assert_eq!(message["minimum_tx_count"], 2);
        assert_eq!(message["within_secs"], 300);
        assert_eq!(message["limit"], 10);
    }

    #[test]
    fn backoff_doubles_then_stops_at_max() {
        let mut backoff = Backoff {
            initial: Duration::from_secs(1),
            max: Duration::from_secs(8),
            attempt: 0,
        };
        assert_eq!(backoff.next_delay(), Duration::from_secs(1));
        assert_eq!(backoff.next_delay(), Duration::from_secs(2));
        assert_eq!(backoff.next_delay(), Duration::from_secs(4));
        assert_eq!(backoff.next_delay(), Duration::from_secs(8));
        assert_eq!(backoff.next_delay(), Duration::from_secs(8));
        backoff.reset();
        assert_eq!(backoff.next_delay(), Duration::from_secs(1));
    }

    #[test]
    fn the_token_never_reaches_a_log_line() {
        let client = FeedClient::with_token(
            FeedConfig::default(),
            Secret::new("tok_live_do_not_print"),
        );
        let rendered = format!("{:?} {}", client.token, client.token);
        assert!(!rendered.contains("tok_live"), "{rendered}");
        assert!(!strip_token("connect failed for ws://h/?token=tok_live_do_not_print")
            .contains("tok_live"));
    }

    #[test]
    fn replays_both_file_shapes() {
        let dir = std::env::temp_dir().join("smb-replay-test");
        std::fs::create_dir_all(&dir).unwrap();

        let lines = dir.join("lines.jsonl");
        let one_line = snapshot_json(SOL).replace('\n', "");
        std::fs::write(&lines, format!("{one_line}\n{one_line}\n")).unwrap();
        assert_eq!(replay_file(&lines, SOL).unwrap().len(), 2);

        let array = dir.join("array.json");
        std::fs::write(&array, format!("[{one_line}]")).unwrap();
        assert_eq!(replay_file(&array, SOL).unwrap().len(), 1);
    }
}
