//! The live route set, updated from each snapshot.
//!
//! The production client reports its snapshot handling as `added / updated /
//! removed` counts plus "reranked pools for N route(s) in place", so the
//! registry keeps routes across snapshots and applies a delta rather than
//! rebuilding.
use crate::observed_feed::{ObservedPool, ObservedRoute, Snapshot};
use crate::selector::{Kind, SelectionParams, kind_of, select};
use std::collections::HashMap;

/// What identifies a route across snapshots: its target, its stock leg (if it
/// has one) and its settlement mint.
#[derive(Debug, Clone, PartialEq, Eq, Hash, PartialOrd, Ord)]
pub struct RouteKey {
    pub target_mint: String,
    pub stock_mint: Option<String>,
    pub settlement_mint: String,
}

impl RouteKey {
    pub fn of(route: &ObservedRoute) -> Self {
        Self {
            target_mint: route.target_mint.clone(),
            stock_mint: route.stock_mint.clone(),
            settlement_mint: route.settlement_mint.clone(),
        }
    }
}

#[derive(Debug, Clone)]
pub struct RegisteredRoute {
    pub route: ObservedRoute,
    pub kind: Kind,
    /// When the route was last present in a snapshot.
    pub last_seen_unix: u64,
}

#[derive(Debug, Default, Clone, PartialEq, Eq)]
pub struct Delta {
    pub added: Vec<RouteKey>,
    pub updated: Vec<RouteKey>,
    pub removed: Vec<RouteKey>,
    /// Routes whose pool order changed without anything else changing.
    pub reranked: Vec<RouteKey>,
}

impl Delta {
    pub fn is_empty(&self) -> bool {
        self.added.is_empty()
            && self.updated.is_empty()
            && self.removed.is_empty()
            && self.reranked.is_empty()
    }
}

#[derive(Debug, Default)]
pub struct RouteRegistry {
    routes: HashMap<RouteKey, RegisteredRoute>,
}

impl RouteRegistry {
    pub fn new() -> Self {
        Self::default()
    }

    pub fn len(&self) -> usize {
        self.routes.len()
    }

    pub fn is_empty(&self) -> bool {
        self.routes.is_empty()
    }

    pub fn get(&self, key: &RouteKey) -> Option<&RegisteredRoute> {
        self.routes.get(key)
    }

    /// Every live route, richest first.
    pub fn routes(&self) -> Vec<&RegisteredRoute> {
        let mut live: Vec<_> = self.routes.values().collect();
        live.sort_by(|a, b| {
            b.route
                .max_net_profit
                .cmp(&a.route.max_net_profit)
                .then_with(|| a.route.target_mint.cmp(&b.route.target_mint))
        });
        live
    }

    /// Applies one snapshot: routes it keeps are added or updated, routes it no
    /// longer carries are removed. Only the routes [`select`] keeps enter the
    /// registry, so a filtered-out route is removed like a vanished one.
    pub fn apply_snapshot(
        &mut self,
        snapshot: &Snapshot,
        settlement_mint: &str,
        params: &SelectionParams,
    ) -> Delta {
        let (kept, _) = select(snapshot, settlement_mint, params);
        let mut delta = Delta::default();
        let mut present = Vec::with_capacity(kept.len());
        for route in kept {
            let key = RouteKey::of(route);
            present.push(key.clone());
            let mut ranked = route.clone();
            rerank_pools(&mut ranked.pools);
            match self.routes.get_mut(&key) {
                None => {
                    self.routes.insert(
                        key.clone(),
                        RegisteredRoute {
                            kind: kind_of(&ranked),
                            route: ranked,
                            last_seen_unix: snapshot.generated_at_unix,
                        },
                    );
                    delta.added.push(key);
                }
                Some(existing) => {
                    let order_changed = pool_addresses(&existing.route.pools)
                        != pool_addresses(&ranked.pools);
                    let content_changed = existing.route.max_net_profit != ranked.max_net_profit
                        || existing.route.total_net_profit != ranked.total_net_profit
                        || existing.route.profitable_tx_count != ranked.profitable_tx_count
                        || existing.route.pools.len() != ranked.pools.len()
                        || existing.route.lookup_tables != ranked.lookup_tables;
                    existing.kind = kind_of(&ranked);
                    existing.route = ranked;
                    existing.last_seen_unix = snapshot.generated_at_unix;
                    if content_changed {
                        delta.updated.push(key);
                    } else if order_changed {
                        delta.reranked.push(key);
                    }
                }
            }
        }
        self.routes.retain(|key, _| {
            let live = present.contains(key);
            if !live {
                delta.removed.push(key.clone());
            }
            live
        });
        delta.added.sort();
        delta.updated.sort();
        delta.removed.sort();
        delta.reranked.sort();
        delta
    }

    /// Drops routes last seen longer than `retention_secs` ago. Snapshots that
    /// keep arriving already remove vanished routes; this covers the feed going
    /// quiet, so a stale route is never traded.
    pub fn expire_stale(&mut self, now_unix: u64, retention_secs: u64) -> Vec<RouteKey> {
        let mut expired = Vec::new();
        self.routes.retain(|key, registered| {
            let fresh = now_unix.saturating_sub(registered.last_seen_unix) <= retention_secs;
            if !fresh {
                expired.push(key.clone());
            }
            fresh
        });
        expired.sort();
        expired
    }
}

fn pool_addresses(pools: &[ObservedPool]) -> Vec<&str> {
    pools.iter().map(|p| p.address.as_str()).collect()
}

/// Best-performing pools first: the ones that actually produced profit, then
/// the size of that profit.
fn rerank_pools(pools: &mut [ObservedPool]) {
    pools.sort_by(|a, b| {
        b.profitable_tx_count
            .cmp(&a.profitable_tx_count)
            .then_with(|| b.max_net_profit.cmp(&a.max_net_profit))
            .then_with(|| b.total_net_profit.cmp(&a.total_net_profit))
            .then_with(|| a.address.cmp(&b.address))
    });
}

#[cfg(test)]
mod tests {
    use super::*;

    const SOL: &str = "So11111111111111111111111111111111111111112";

    fn pool(address: &str, txs: u64, profit: u64) -> ObservedPool {
        ObservedPool {
            address: address.into(),
            dex: "pumpswap".into(),
            lookup_tables: vec![],
            max_net_profit: profit,
            profitable_tx_count: txs,
            role: "direct".into(),
            token_mint_a: None,
            token_mint_b: None,
            total_net_profit: profit,
        }
    }

    fn route(target: &str, profit: u64, pools: Vec<ObservedPool>) -> ObservedRoute {
        ObservedRoute {
            copy_rate: None,
            fees: Default::default(),
            lookup_tables: vec![],
            max_net_profit: profit,
            pools,
            profitable_tx_count: 9,
            settlement_mint: SOL.into(),
            stock_mint: None,
            target_mint: target.into(),
            total_net_profit: profit,
        }
    }

    fn snapshot(at: u64, routes: Vec<ObservedRoute>) -> Snapshot {
        Snapshot {
            bundles: vec![],
            companions: vec![],
            generated_at_unix: at,
            retention_secs: 300,
            routes,
        }
    }

    fn params() -> SelectionParams {
        SelectionParams {
            min_profit: 0,
            minimum_tx_count: 0,
            within_secs: 300,
            limit: 100,
        }
    }

    #[test]
    fn add_then_update_then_remove() {
        let mut reg = RouteRegistry::new();
        let first = snapshot(100, vec![route("a", 10, vec![pool("p1", 1, 1)])]);
        let delta = reg.apply_snapshot(&first, SOL, &params());
        assert_eq!(delta.added.len(), 1);
        assert_eq!(reg.len(), 1);

        let second = snapshot(110, vec![route("a", 99, vec![pool("p1", 1, 1)])]);
        let delta = reg.apply_snapshot(&second, SOL, &params());
        assert!(delta.added.is_empty());
        assert_eq!(delta.updated.len(), 1);

        let third = snapshot(120, vec![]);
        let delta = reg.apply_snapshot(&third, SOL, &params());
        assert_eq!(delta.removed.len(), 1);
        assert!(reg.is_empty());
    }

    #[test]
    fn unchanged_snapshot_produces_no_delta() {
        let mut reg = RouteRegistry::new();
        let snap = snapshot(100, vec![route("a", 10, vec![pool("p1", 1, 1)])]);
        reg.apply_snapshot(&snap, SOL, &params());
        let delta = reg.apply_snapshot(&snap, SOL, &params());
        assert!(delta.is_empty(), "{delta:?}");
    }

    #[test]
    fn pools_are_reranked_by_realised_profit() {
        let mut reg = RouteRegistry::new();
        let snap = snapshot(
            100,
            vec![route(
                "a",
                10,
                vec![pool("cold", 0, 0), pool("hot", 7, 500), pool("warm", 3, 50)],
            )],
        );
        reg.apply_snapshot(&snap, SOL, &params());
        let key = RouteKey {
            target_mint: "a".into(),
            stock_mint: None,
            settlement_mint: SOL.into(),
        };
        let order = pool_addresses(&reg.get(&key).unwrap().route.pools);
        assert_eq!(order, vec!["hot", "warm", "cold"]);
    }

    #[test]
    fn reordered_pools_count_as_rerank_not_update() {
        let mut reg = RouteRegistry::new();
        let a = route("a", 10, vec![pool("x", 5, 5), pool("y", 1, 1)]);
        reg.apply_snapshot(&snapshot(100, vec![a]), SOL, &params());
        // Same pools, different profit ranking inside the route.
        let b = route("a", 10, vec![pool("x", 1, 1), pool("y", 5, 5)]);
        let delta = reg.apply_snapshot(&snapshot(110, vec![b]), SOL, &params());
        assert!(delta.updated.is_empty(), "{delta:?}");
        assert_eq!(delta.reranked.len(), 1);
    }

    #[test]
    fn stale_routes_expire_when_the_feed_goes_quiet() {
        let mut reg = RouteRegistry::new();
        reg.apply_snapshot(
            &snapshot(100, vec![route("a", 10, vec![pool("p", 1, 1)])]),
            SOL,
            &params(),
        );
        assert!(reg.expire_stale(300, 300).is_empty());
        assert_eq!(reg.expire_stale(401, 300).len(), 1);
        assert!(reg.is_empty());
    }

    #[test]
    fn filtered_out_route_leaves_the_registry() {
        let mut reg = RouteRegistry::new();
        let strict = SelectionParams {
            min_profit: 50,
            ..params()
        };
        reg.apply_snapshot(
            &snapshot(100, vec![route("a", 100, vec![pool("p", 1, 1)])]),
            SOL,
            &strict,
        );
        assert_eq!(reg.len(), 1);
        let delta = reg.apply_snapshot(
            &snapshot(110, vec![route("a", 10, vec![pool("p", 1, 1)])]),
            SOL,
            &strict,
        );
        assert_eq!(delta.removed.len(), 1);
        assert!(reg.is_empty());
    }
}
